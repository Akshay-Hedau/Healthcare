```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
```


```python
health = pd.read_excel('healthcare.xlsx')
```


```python
health.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>3</td>
      <td>145</td>
      <td>233</td>
      <td>1</td>
      <td>0</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130</td>
      <td>250</td>
      <td>0</td>
      <td>1</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>204</td>
      <td>0</td>
      <td>0</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>56</td>
      <td>1</td>
      <td>1</td>
      <td>120</td>
      <td>236</td>
      <td>0</td>
      <td>1</td>
      <td>178</td>
      <td>0</td>
      <td>0.8</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>57</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>354</td>
      <td>0</td>
      <td>1</td>
      <td>163</td>
      <td>1</td>
      <td>0.6</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
health.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>298</th>
      <td>57</td>
      <td>0</td>
      <td>0</td>
      <td>140</td>
      <td>241</td>
      <td>0</td>
      <td>1</td>
      <td>123</td>
      <td>1</td>
      <td>0.2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>299</th>
      <td>45</td>
      <td>1</td>
      <td>3</td>
      <td>110</td>
      <td>264</td>
      <td>0</td>
      <td>1</td>
      <td>132</td>
      <td>0</td>
      <td>1.2</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>300</th>
      <td>68</td>
      <td>1</td>
      <td>0</td>
      <td>144</td>
      <td>193</td>
      <td>1</td>
      <td>1</td>
      <td>141</td>
      <td>0</td>
      <td>3.4</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>301</th>
      <td>57</td>
      <td>1</td>
      <td>0</td>
      <td>130</td>
      <td>131</td>
      <td>0</td>
      <td>1</td>
      <td>115</td>
      <td>1</td>
      <td>1.2</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>0</td>
    </tr>
    <tr>
      <th>302</th>
      <td>57</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>236</td>
      <td>0</td>
      <td>0</td>
      <td>174</td>
      <td>0</td>
      <td>0.0</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



1(a)-Perform preliminary data inspection and report the findings on the structure of the data, missing values, duplicates, etc.


```python
health.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 303 entries, 0 to 302
    Data columns (total 14 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   age       303 non-null    int64  
     1   sex       303 non-null    int64  
     2   cp        303 non-null    int64  
     3   trestbps  303 non-null    int64  
     4   chol      303 non-null    int64  
     5   fbs       303 non-null    int64  
     6   restecg   303 non-null    int64  
     7   thalach   303 non-null    int64  
     8   exang     303 non-null    int64  
     9   oldpeak   303 non-null    float64
     10  slope     303 non-null    int64  
     11  ca        303 non-null    int64  
     12  thal      303 non-null    int64  
     13  target    303 non-null    int64  
    dtypes: float64(1), int64(13)
    memory usage: 33.3 KB



```python
health.shape
```




    (303, 14)




```python
health.describe().T
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>count</th>
      <th>mean</th>
      <th>std</th>
      <th>min</th>
      <th>25%</th>
      <th>50%</th>
      <th>75%</th>
      <th>max</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>age</th>
      <td>303.0</td>
      <td>54.366337</td>
      <td>9.082101</td>
      <td>29.0</td>
      <td>47.5</td>
      <td>55.0</td>
      <td>61.0</td>
      <td>77.0</td>
    </tr>
    <tr>
      <th>sex</th>
      <td>303.0</td>
      <td>0.683168</td>
      <td>0.466011</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>cp</th>
      <td>303.0</td>
      <td>0.966997</td>
      <td>1.032052</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>trestbps</th>
      <td>303.0</td>
      <td>131.623762</td>
      <td>17.538143</td>
      <td>94.0</td>
      <td>120.0</td>
      <td>130.0</td>
      <td>140.0</td>
      <td>200.0</td>
    </tr>
    <tr>
      <th>chol</th>
      <td>303.0</td>
      <td>246.264026</td>
      <td>51.830751</td>
      <td>126.0</td>
      <td>211.0</td>
      <td>240.0</td>
      <td>274.5</td>
      <td>564.0</td>
    </tr>
    <tr>
      <th>fbs</th>
      <td>303.0</td>
      <td>0.148515</td>
      <td>0.356198</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>restecg</th>
      <td>303.0</td>
      <td>0.528053</td>
      <td>0.525860</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>thalach</th>
      <td>303.0</td>
      <td>149.646865</td>
      <td>22.905161</td>
      <td>71.0</td>
      <td>133.5</td>
      <td>153.0</td>
      <td>166.0</td>
      <td>202.0</td>
    </tr>
    <tr>
      <th>exang</th>
      <td>303.0</td>
      <td>0.326733</td>
      <td>0.469794</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>oldpeak</th>
      <td>303.0</td>
      <td>1.039604</td>
      <td>1.161075</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.8</td>
      <td>1.6</td>
      <td>6.2</td>
    </tr>
    <tr>
      <th>slope</th>
      <td>303.0</td>
      <td>1.399340</td>
      <td>0.616226</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>2.0</td>
    </tr>
    <tr>
      <th>ca</th>
      <td>303.0</td>
      <td>0.729373</td>
      <td>1.022606</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>thal</th>
      <td>303.0</td>
      <td>2.313531</td>
      <td>0.612277</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>2.0</td>
      <td>3.0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>target</th>
      <td>303.0</td>
      <td>0.544554</td>
      <td>0.498835</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
health.isna().sum()
```




    age         0
    sex         0
    cp          0
    trestbps    0
    chol        0
    fbs         0
    restecg     0
    thalach     0
    exang       0
    oldpeak     0
    slope       0
    ca          0
    thal        0
    target      0
    dtype: int64




```python
health[health.duplicated(keep= False)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>163</th>
      <td>38</td>
      <td>1</td>
      <td>2</td>
      <td>138</td>
      <td>175</td>
      <td>0</td>
      <td>1</td>
      <td>173</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>164</th>
      <td>38</td>
      <td>1</td>
      <td>2</td>
      <td>138</td>
      <td>175</td>
      <td>0</td>
      <td>1</td>
      <td>173</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>4</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>



Our Data has no Missing Values, but it has a Duplicate ROW.

1(b) Based on these findings, remove duplicates (if any) and treat missing values using an appropriate strategy.


```python
#Drop the Duplicate Row.
health = health.drop(164)
```


```python
#Check size after dropping the duplicate row.
health.shape
```




    (302, 14)




```python
health[health.duplicated(keep= False)]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>



NOW no Duplicate Values.

CONCLUSION-
1. There are no missing values in our DataFrame.
2. Thare are no Duplicates in our DataFrame.
3. Our data has 302 ROWS and 14 COLUMNS.

2. Prepare a report about the data explaining the distribution of the disease and the related factors using the steps listed below:

  2.(a)Get a preliminary statistical summary of the data and explore the measures of central tendencies and spread of the data.


```python
#Check the Distribution of Age in our Data.

plt.figure(figsize= (8,6))

sns.displot(data= health, x= "age")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_19_1.png)


* Age is Continuous Feature and Normally Distributed. 


```python
#Check Sex column usng Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "sex")

plt.show()
```


![png](output_21_0.png)



```python
health["sex"].value_counts()
```




    1    206
    0     96
    Name: sex, dtype: int64



* 0 is for FEMALE and 1 is for MALE
* Here we can see that we have twice the number of observations for MALE than FEMALE. 


```python
#Check CP column (Chest Pain) using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "cp")

plt.show()
```


![png](output_24_0.png)



```python
health["cp"].value_counts()
```




    0    143
    2     86
    1     50
    3     23
    Name: cp, dtype: int64



* Chest Pain (cp): seems to be ordinal Categorical Variable.


```python
#Check trestbps column using Distribution Plot.

plt.figure(figsize= (8,6))

sns.displot(data= health, x= "trestbps")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_27_1.png)


* Resting Blood Pressure(trestbps) is Continuous and seems to be Normally Distributed with Some Outliers at Right Tail.


```python
#Check chol column using Distribution Plot.

plt.figure(figsize= (8,6))

sns.displot(data= health, x= "chol")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_29_1.png)


* Here we can see that Cholestrol(chol) is Continuous and Normally Distributed with some Outliers on the Right.


```python
#Check fbs column using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "fbs")

plt.show()
```


![png](output_31_0.png)



```python
health["fbs"].value_counts()
```




    0    257
    1     45
    Name: fbs, dtype: int64



* Fasting Blood Sugar "fbs" is Ordinal Categorical Feature.


```python
#Check column restecg using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "restecg")

plt.show()
```


![png](output_34_0.png)



```python
health["restecg"].value_counts()
```




    1    151
    0    147
    2      4
    Name: restecg, dtype: int64



* Resting electrocardiographic results "restecg" is Ordinal Categorical Feature.


```python
#Check thalac column using Distribution Plot.

plt.figure(figsize= (8,6))

sns.displot(data= health, x= "thalach")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_37_1.png)


* Maximum Heart Rate Achieved "thalach" is Continuous Feature and it is Left Skewed.


```python
#Check for column exang using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "exang")

plt.show()
```


![png](output_39_0.png)



```python
health["exang"].value_counts()
```




    0    203
    1     99
    Name: exang, dtype: int64



* Exercise Induced Enigma(exang) is Categorical Feature.


```python
#Check for column oldpeak using Distribution Plot.

plt.figure(figsize= (8,6))

sns.displot(data= health, x= "oldpeak")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_42_1.png)


* ST depression induced by exercise relative to rest "oldpeak" is Continuous Feature and it is Highly Right Skewed.


```python
#Check for column slope using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "slope")

plt.show()
```


![png](output_44_0.png)



```python
health["slope"].value_counts()
```




    2    141
    1    140
    0     21
    Name: slope, dtype: int64



* Slope of the peak exercise ST segment "slope" is Ordinal Categorical Feature.


```python
#Check for column 'ca' using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "ca")

plt.show()
```


![png](output_47_0.png)



```python
health["ca"].value_counts()
```




    0    175
    1     65
    2     38
    3     20
    4      4
    Name: ca, dtype: int64



* Number of major vessels (0-3) colored by fluoroscopy "ca" is Ordinal Categorical Feature.


```python
#Check for column 'thal' using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "thal")

plt.show()
```


![png](output_50_0.png)



```python
health["thal"].value_counts()
```




    2    165
    3    117
    1     18
    0      2
    Name: thal, dtype: int64



* Thalassaemia "thal" is Nominal Categorical Variable.


```python
#Check for column 'target' using Count Plot.

plt.figure(figsize= (8,6))

sns.countplot(data= health, x= "target")

plt.show()
```


![png](output_53_0.png)



```python
health["target"].value_counts()
```




    1    164
    0    138
    Name: target, dtype: int64



* "target" is our Target Variable and we have No Class Imbalance here.

2.(b).	Identify the data variables which are categorical and describe and explore these variables using the appropriate tools, such as count plot.


```python
health.dtypes
```




    age           int64
    sex           int64
    cp            int64
    trestbps      int64
    chol          int64
    fbs           int64
    restecg       int64
    thalach       int64
    exang         int64
    oldpeak     float64
    slope         int64
    ca            int64
    thal          int64
    target        int64
    dtype: object




```python
for col in health.columns:
    print(f"Number of Unique Values in {col} : {health[col].nunique()}")
```

    Number of Unique Values in age : 41
    Number of Unique Values in sex : 2
    Number of Unique Values in cp : 4
    Number of Unique Values in trestbps : 49
    Number of Unique Values in chol : 152
    Number of Unique Values in fbs : 2
    Number of Unique Values in restecg : 3
    Number of Unique Values in thalach : 91
    Number of Unique Values in exang : 2
    Number of Unique Values in oldpeak : 40
    Number of Unique Values in slope : 3
    Number of Unique Values in ca : 5
    Number of Unique Values in thal : 4
    Number of Unique Values in target : 2



```python
for col in health.columns:
   
    if health[col].nunique() <= 5:
        
        plt.figure(figsize= (6,4))

        sns.countplot(data= health, x= col)
        
        plt.title(f"Countplot of {col}")

        plt.show()
```


![png](output_59_0.png)



![png](output_59_1.png)



![png](output_59_2.png)



![png](output_59_3.png)



![png](output_59_4.png)



![png](output_59_5.png)



![png](output_59_6.png)



![png](output_59_7.png)



![png](output_59_8.png)


2.(c).	Study the occurrence of CVD across the Age category


```python
plt.figure(figsize= (8,6))

sns.displot(data= health, x= "age", col= "target")

plt.show()
```


    <Figure size 576x432 with 0 Axes>



![png](output_61_1.png)


* 40-70 seems to be the Age range Where there are more chances of Cardiovascular Diseases.
* Although, looking at target= 0 graph, 55-62 seems to be the Age Range in which Amny Observations from Our Data have no CVD.
* Also, CVD seems to be present in all Age Ranges in our Data, which can be a Cause of Concern.

2.(d). Study the composition of all patients with respect to the Sex category.


```python
# We will Compare Features of all Observations with respect to Gender.
```


```python
for cols in health.drop("sex",axis= 1).columns:
    
    if health[cols].nunique() <= 5:
        
        plt.figure(figsize= (6,4))

        sns.countplot(data= health, x= cols, hue= "sex")
        
        plt.title(f"Countplot of {cols}")

        plt.show()
        
    else:
        
        plt.figure(figsize= (6,4))

        sns.displot(data= health, x= cols, col= "sex")
        
        plt.title(f"Distribution of {cols} by Gender:")

        plt.show()
        
```


    <Figure size 432x288 with 0 Axes>



![png](output_65_1.png)



![png](output_65_2.png)



    <Figure size 432x288 with 0 Axes>



![png](output_65_4.png)



    <Figure size 432x288 with 0 Axes>



![png](output_65_6.png)



![png](output_65_7.png)



![png](output_65_8.png)



    <Figure size 432x288 with 0 Axes>



![png](output_65_10.png)



![png](output_65_11.png)



    <Figure size 432x288 with 0 Axes>



![png](output_65_13.png)



![png](output_65_14.png)



![png](output_65_15.png)



![png](output_65_16.png)



![png](output_65_17.png)


2.(e).Study if one can detect heart attacks based on anomalies in the resting blood pressure (trestbps) of a patient


```python
plt.figure(figsize= (6,4))

sns.displot(data= health, x= "trestbps", col= "target")

plt.show()
```


    <Figure size 432x288 with 0 Axes>



![png](output_67_1.png)


* We have some observations with very High Resting Blood Pressure values without occurence of CVD.
* In general, we can see that Resting Blood Pressure values from 120-160 has more chances of CVD.
* Still, This feature alone can not be said to be conclusive of CVD.

2.(f).Describe the relationship between cholesterol levels and a target variable.


```python
plt.figure(figsize= (6,4))

sns.displot(data= health, x= "chol", col= "target")

plt.show()
```


    <Figure size 432x288 with 0 Axes>



![png](output_70_1.png)


* Here too, No considerable conclusion can be made about CVD by Cholesterol Levels alone.

2.(g). State what relationship exists between peak exercising and the occurrence of a heart attack.


```python
plt.figure(figsize= (6,4))

sns.displot(data= health, x= "oldpeak", col= "target")

plt.show()
```


    <Figure size 432x288 with 0 Axes>



![png](output_73_1.png)


* As can be seen above, Lower Values of ST Depression Induced by Exercise relative to Rest clearly has more chances of CVD Occurence.


```python
plt.figure(figsize= (6,4))

sns.countplot(data= health, x= "slope", hue= "target")

plt.show()
```


![png](output_75_0.png)


* Clear Relationship Between Slope of the Peak Exercise ST Segment and Occurence of CVD, having more value of "slope" clearly has more chances of CVD Occurence.

2.(h). Check if thalassemia is a major cause of CVD.


```python
plt.figure(figsize= (6,4))

sns.countplot(data= health, x= "thal", hue= "target")

plt.show()
```


![png](output_78_0.png)


* As can be seen clearly, Thalassemia seems to be major Factor in Occurence of CVD.

2.(i). List how the other factors determine the occurrence of CVD.


```python
plt.figure(figsize= (18,8), dpi= 200)

sns.heatmap(health.corr(), annot= True)

plt.show()
```


![png](output_81_0.png)


* Chest Pain (cp), Maximum Heart Rate Achieved (thalach), Slope of the peak exercise ST segment (slope) have Decently High Positive Correlation with Occurence of CVD.

* Exercise Induced Enigma (exang), ST depression induced by exercise relative to rest (oldpeak), Number of major vessels (0-3) colored by fluoroscopy (ca) and 
  Thalassemia (thal) have Decently High Negative Correlation with Occurence of CVD.

* Cholesterol (chol) and Fasting Blood Sugar (fbs) have Very Low Correlation to Heart Disease.

2.(j). Use a pair plot to understand the relationship between all the given variables.


```python
plt.figure(dpi= 200)

sns.pairplot(health, hue= "target")

plt.show()
```


    <Figure size 1200x800 with 0 Axes>



![png](output_84_1.png)


* There aren't any Clearly Discernible Relationship Between any of the Features.

3.	Build a baseline model to predict the risk of a heart attack using a logistic regression and random forest and explore the results while using correlation analysis and logistic regression (leveraging standard error and p-values from statsmodels) for feature selection.


```python
#Separate Features and Target into diffrent DataFrame.
x = health.drop("target", axis= 1)
```


```python
x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>3</td>
      <td>145</td>
      <td>233</td>
      <td>1</td>
      <td>0</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130</td>
      <td>250</td>
      <td>0</td>
      <td>1</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>204</td>
      <td>0</td>
      <td>0</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>56</td>
      <td>1</td>
      <td>1</td>
      <td>120</td>
      <td>236</td>
      <td>0</td>
      <td>1</td>
      <td>178</td>
      <td>0</td>
      <td>0.8</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>57</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>354</td>
      <td>0</td>
      <td>1</td>
      <td>163</td>
      <td>1</td>
      <td>0.6</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>




```python
x.shape
```




    (302, 13)




```python
y = health["target"]
```


```python
y.head()
```




    0    1
    1    1
    2    1
    3    1
    4    1
    Name: target, dtype: int64




```python
y.shape
```




    (302,)



Using Generalized Linear Model from statsmodel library to determine which Features are Significant in Decidind Target Variable.


```python
from statsmodels.api import GLM
glm_model = GLM(y, x)
```


```python
glm_results = glm_model.fit()
```


```python
glm_results.summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>target</td>      <th>  No. Observations:  </th>  <td>   302</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>   289</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Gaussian</td>     <th>  Df Model:          </th>  <td>    12</td> 
</tr>
<tr>
  <th>Link Function:</th>       <td>identity</td>     <th>  Scale:             </th> <td> 0.12814</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -111.63</td>
</tr>
<tr>
  <th>Date:</th>            <td>Mon, 05 Dec 2022</td> <th>  Deviance:          </th> <td>  37.034</td>
</tr>
<tr>
  <th>Time:</th>                <td>14:21:57</td>     <th>  Pearson chi2:      </th>  <td>  37.0</td> 
</tr>
<tr>
  <th>No. Iterations:</th>          <td>3</td>        <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>        <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>age</th>      <td>    0.0035</td> <td>    0.002</td> <td>    1.503</td> <td> 0.133</td> <td>   -0.001</td> <td>    0.008</td>
</tr>
<tr>
  <th>sex</th>      <td>   -0.1706</td> <td>    0.047</td> <td>   -3.652</td> <td> 0.000</td> <td>   -0.262</td> <td>   -0.079</td>
</tr>
<tr>
  <th>cp</th>       <td>    0.1091</td> <td>    0.023</td> <td>    4.812</td> <td> 0.000</td> <td>    0.065</td> <td>    0.154</td>
</tr>
<tr>
  <th>trestbps</th> <td>   -0.0008</td> <td>    0.001</td> <td>   -0.708</td> <td> 0.479</td> <td>   -0.003</td> <td>    0.001</td>
</tr>
<tr>
  <th>chol</th>     <td>   -0.0001</td> <td>    0.000</td> <td>   -0.254</td> <td> 0.799</td> <td>   -0.001</td> <td>    0.001</td>
</tr>
<tr>
  <th>fbs</th>      <td>    0.0084</td> <td>    0.060</td> <td>    0.139</td> <td> 0.889</td> <td>   -0.110</td> <td>    0.126</td>
</tr>
<tr>
  <th>restecg</th>  <td>    0.0686</td> <td>    0.040</td> <td>    1.728</td> <td> 0.084</td> <td>   -0.009</td> <td>    0.146</td>
</tr>
<tr>
  <th>thalach</th>  <td>    0.0050</td> <td>    0.001</td> <td>    5.605</td> <td> 0.000</td> <td>    0.003</td> <td>    0.007</td>
</tr>
<tr>
  <th>exang</th>    <td>   -0.1202</td> <td>    0.051</td> <td>   -2.350</td> <td> 0.019</td> <td>   -0.221</td> <td>   -0.020</td>
</tr>
<tr>
  <th>oldpeak</th>  <td>   -0.0526</td> <td>    0.023</td> <td>   -2.274</td> <td> 0.023</td> <td>   -0.098</td> <td>   -0.007</td>
</tr>
<tr>
  <th>slope</th>    <td>    0.0887</td> <td>    0.043</td> <td>    2.078</td> <td> 0.038</td> <td>    0.005</td> <td>    0.172</td>
</tr>
<tr>
  <th>ca</th>       <td>   -0.1120</td> <td>    0.023</td> <td>   -4.924</td> <td> 0.000</td> <td>   -0.157</td> <td>   -0.067</td>
</tr>
<tr>
  <th>thal</th>     <td>   -0.1021</td> <td>    0.036</td> <td>   -2.866</td> <td> 0.004</td> <td>   -0.172</td> <td>   -0.032</td>
</tr>
</table>



* There are Some Features which Have p-Value > 0.05.

* Those Features are not Significant in Predicting Target Variable.

* We will Build our Model Twice, once Using all The Features and Once Using Only Those Features deemed Significant by GLM.

Creating new Data Frame with Feature deemed Significan by GLM.


```python
glm_results.pvalues
```




    age         1.329240e-01
    sex         2.602821e-04
    cp          1.491747e-06
    trestbps    4.789596e-01
    chol        7.991127e-01
    fbs         8.894247e-01
    restecg     8.391343e-02
    thalach     2.086209e-08
    exang       1.879360e-02
    oldpeak     2.297834e-02
    slope       3.773797e-02
    ca          8.465524e-07
    thal        4.157151e-03
    dtype: float64




```python
glm_results.pvalues[glm_results.pvalues < 0.05]
```




    sex        2.602821e-04
    cp         1.491747e-06
    thalach    2.086209e-08
    exang      1.879360e-02
    oldpeak    2.297834e-02
    slope      3.773797e-02
    ca         8.465524e-07
    thal       4.157151e-03
    dtype: float64




```python
significant_cols = list(glm_results.pvalues[glm_results.pvalues < 0.05].index)
```


```python
significant_cols
```




    ['sex', 'cp', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal']




```python
x_glm = x[significant_cols].copy()
```


```python
x_glm.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sex</th>
      <th>cp</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>3</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>2</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>1</td>
      <td>178</td>
      <td>0</td>
      <td>0.8</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>163</td>
      <td>1</td>
      <td>0.6</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



Train Test Split of Datafrmae with All Features:


```python
from sklearn.model_selection import train_test_split, GridSearchCV
```


```python
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size= 0.2, random_state= 42)
```


```python
print(x_train.shape)
print(x_test.shape)
print(y_train.shape)
print(y_test.shape)
```

    (241, 13)
    (61, 13)
    (241,)
    (61,)


Train Test Split of Datafrmae with GLM Features:


```python
x_glm_train, x_glm_test, y_train, y_test = train_test_split(x_glm, y, test_size= 0.2, random_state= 42)
```


```python
print(x_glm_train.shape)
print(x_glm_test.shape)
print(y_train.shape)
print(y_test.shape)
```

    (241, 8)
    (61, 8)
    (241,)
    (61,)


Scalling of Datafrmae with All Features:


```python
from sklearn.preprocessing import StandardScaler
```


```python
sc_all = StandardScaler()
```


```python
temp = sc_all.fit_transform(x_train)
x_train = pd.DataFrame(temp, columns= x_train.columns)
x_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>-1.350641</td>
      <td>0.731459</td>
      <td>0.000000</td>
      <td>-0.630711</td>
      <td>0.927138</td>
      <td>-0.391293</td>
      <td>0.890028</td>
      <td>0.549139</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.487426</td>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>2.753363</td>
      <td>0.526980</td>
      <td>2.555631</td>
      <td>-0.991522</td>
      <td>0.012071</td>
      <td>1.517027</td>
      <td>0.543474</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.378270</td>
      <td>0.731459</td>
      <td>-0.966493</td>
      <td>-0.348705</td>
      <td>0.145878</td>
      <td>2.555631</td>
      <td>0.890028</td>
      <td>0.593894</td>
      <td>-0.659184</td>
      <td>-0.715923</td>
      <td>-0.684707</td>
      <td>1.350103</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.068393</td>
      <td>-1.367131</td>
      <td>0.000000</td>
      <td>0.215308</td>
      <td>0.069658</td>
      <td>-0.391293</td>
      <td>-0.991522</td>
      <td>0.504383</td>
      <td>-0.659184</td>
      <td>0.363560</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.050801</td>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>0.497314</td>
      <td>1.689342</td>
      <td>-0.391293</td>
      <td>0.890028</td>
      <td>0.370116</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
  </tbody>
</table>
</div>




```python
temp = sc_all.transform(x_test)
x_test = pd.DataFrame(temp, columns= x_test.columns)
x_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.068393</td>
      <td>0.731459</td>
      <td>-0.966493</td>
      <td>0.046104</td>
      <td>2.032334</td>
      <td>-0.391293</td>
      <td>0.890028</td>
      <td>-0.793531</td>
      <td>1.517027</td>
      <td>0.183647</td>
      <td>-0.684707</td>
      <td>0.333307</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.050801</td>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>-0.348705</td>
      <td>1.193909</td>
      <td>-0.391293</td>
      <td>0.890028</td>
      <td>-0.838286</td>
      <td>1.517027</td>
      <td>0.723388</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.286705</td>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>1.061326</td>
      <td>-2.293175</td>
      <td>2.555631</td>
      <td>0.890028</td>
      <td>1.041451</td>
      <td>-0.659184</td>
      <td>-0.715923</td>
      <td>0.965436</td>
      <td>0.333307</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.269113</td>
      <td>0.731459</td>
      <td>0.000000</td>
      <td>1.625339</td>
      <td>-0.006563</td>
      <td>-0.391293</td>
      <td>0.890028</td>
      <td>-1.330598</td>
      <td>1.517027</td>
      <td>-0.895837</td>
      <td>-0.684707</td>
      <td>2.366899</td>
      <td>-2.232025</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.814896</td>
      <td>-1.367131</td>
      <td>0.966493</td>
      <td>-1.194723</td>
      <td>0.355484</td>
      <td>2.555631</td>
      <td>-0.991522</td>
      <td>-0.883042</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>0.333307</td>
      <td>-0.545762</td>
    </tr>
  </tbody>
</table>
</div>



Scalling of Datafrmae with GLM Features:


```python
sc_glm = StandardScaler()
```


```python
temp = sc_glm.fit_transform(x_glm_train)
x_glm_train = pd.DataFrame(temp, columns= x_glm_train.columns)
x_glm_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sex</th>
      <th>cp</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.731459</td>
      <td>0.000000</td>
      <td>0.549139</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>0.012071</td>
      <td>1.517027</td>
      <td>0.543474</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.731459</td>
      <td>-0.966493</td>
      <td>0.593894</td>
      <td>-0.659184</td>
      <td>-0.715923</td>
      <td>-0.684707</td>
      <td>1.350103</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>3</th>
      <td>-1.367131</td>
      <td>0.000000</td>
      <td>0.504383</td>
      <td>-0.659184</td>
      <td>0.363560</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>0.370116</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>-0.683490</td>
      <td>-0.545762</td>
    </tr>
  </tbody>
</table>
</div>




```python
temp = sc_glm.transform(x_glm_test)
x_glm_test = pd.DataFrame(temp, columns= x_glm_test.columns)
x_glm_test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>sex</th>
      <th>cp</th>
      <th>thalach</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.731459</td>
      <td>-0.966493</td>
      <td>-0.793531</td>
      <td>1.517027</td>
      <td>0.183647</td>
      <td>-0.684707</td>
      <td>0.333307</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>-0.838286</td>
      <td>1.517027</td>
      <td>0.723388</td>
      <td>-0.684707</td>
      <td>-0.683490</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.731459</td>
      <td>0.966493</td>
      <td>1.041451</td>
      <td>-0.659184</td>
      <td>-0.715923</td>
      <td>0.965436</td>
      <td>0.333307</td>
      <td>1.140502</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.731459</td>
      <td>0.000000</td>
      <td>-1.330598</td>
      <td>1.517027</td>
      <td>-0.895837</td>
      <td>-0.684707</td>
      <td>2.366899</td>
      <td>-2.232025</td>
    </tr>
    <tr>
      <th>4</th>
      <td>-1.367131</td>
      <td>0.966493</td>
      <td>-0.883042</td>
      <td>-0.659184</td>
      <td>-0.895837</td>
      <td>0.965436</td>
      <td>0.333307</td>
      <td>-0.545762</td>
    </tr>
  </tbody>
</table>
</div>



** Building Logistic Regression Model and Random Forest Model:

* Logistic Regression Model Using All Features:


```python
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.metrics import plot_confusion_matrix
```


```python
log_model_all = LogisticRegression()
```


```python
log_model_all.fit(x_train, y_train)
```




    LogisticRegression()




```python
preds = log_model_all.predict(x_test)
```


```python
print(classification_report(y_test, preds))
```

                  precision    recall  f1-score   support
    
               0       0.81      0.86      0.83        29
               1       0.87      0.81      0.84        32
    
        accuracy                           0.84        61
       macro avg       0.84      0.84      0.84        61
    weighted avg       0.84      0.84      0.84        61
    



```python
plot_confusion_matrix(log_model_all, x_test, y_test)
plt.show()
```


![png](output_128_0.png)


* Logistic Regression Model Using GLM Features:


```python
log_model_glm = LogisticRegression()
```


```python
log_model_glm.fit(x_glm_train, y_train)
```




    LogisticRegression()




```python
preds = log_model_glm.predict(x_glm_test)
```


```python
print(classification_report(y_test, preds))
```

                  precision    recall  f1-score   support
    
               0       0.86      0.83      0.84        29
               1       0.85      0.88      0.86        32
    
        accuracy                           0.85        61
       macro avg       0.85      0.85      0.85        61
    weighted avg       0.85      0.85      0.85        61
    



```python
plot_confusion_matrix(log_model_glm, x_glm_test, y_test)
plt.show()
```


![png](output_134_0.png)


* Random Forest Classifier Using All Features:


```python
from sklearn.ensemble import RandomForestClassifier
```


```python
rf_model_all = RandomForestClassifier()

rf_model_all.fit(x_train, y_train)

preds = rf_model_all.predict(x_test)

print(classification_report(y_test, preds))
```

                  precision    recall  f1-score   support
    
               0       0.84      0.90      0.87        29
               1       0.90      0.84      0.87        32
    
        accuracy                           0.87        61
       macro avg       0.87      0.87      0.87        61
    weighted avg       0.87      0.87      0.87        61
    



```python
plot_confusion_matrix(rf_model_all, x_test, y_test)
plt.show()
```


![png](output_138_0.png)


* Random Forest Classifier Using GLM Features:


```python
rf_model_glm = RandomForestClassifier()

rf_model_glm.fit(x_glm_train, y_train)

preds = rf_model_glm.predict(x_glm_test)

print(classification_report(y_test, preds))
```

                  precision    recall  f1-score   support
    
               0       0.86      0.86      0.86        29
               1       0.88      0.88      0.88        32
    
        accuracy                           0.87        61
       macro avg       0.87      0.87      0.87        61
    weighted avg       0.87      0.87      0.87        61
    



```python
plot_confusion_matrix(rf_model_glm, x_glm_test, y_test)
plt.show()
```


![png](output_141_0.png)


* We should use Significant Features Found using GLM to Train and Build Model to Predict CVD as it uses less features to Provide same Rate of Accuracy.
